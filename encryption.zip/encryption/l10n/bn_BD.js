OC.L10N.register(
    "encryption",
    {
    "Recovery key successfully enabled" : "পূনরুদ্ধার চাবি সার্থকভাবে কার্যকর করা হয়েছে",
    "Recovery key successfully disabled" : "পূনরুদ্ধার চাবি সার্থকভাবে অকার্যকর করা হয়েছে",
    "Password successfully changed." : "আপনার কূটশব্দটি সার্থকভাবে পরিবর্তন করা হয়েছে ",
    "Cheers!" : "শুভেচ্ছা!",
    "Change recovery key password:" : "পূণরূদ্ধার কি এর কুটশব্দ পরিবর্তন করুন:",
    "Change Password" : "কূটশব্দ পরিবর্তন করুন",
    "Enabled" : "কার্যকর",
    "Disabled" : "অকার্যকর"
},
"nplurals=2; plural=(n != 1);");
