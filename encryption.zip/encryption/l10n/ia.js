OC.L10N.register(
    "encryption",
    {
    "The share will expire on %s." : "Le compartir expirara le %s.",
    "Cheers!" : "Acclamationes!"
},
"nplurals=2; plural=(n != 1);");
