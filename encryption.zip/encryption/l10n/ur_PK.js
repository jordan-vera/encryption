OC.L10N.register(
    "encryption",
    {
    "Cheers!" : "واہ!"
},
"nplurals=2; plural=(n != 1);");
