OC.L10N.register(
    "encryption",
    {
    "Invalid private key for Encryption App. Please update your private key password in your personal settings to recover access to your encrypted files." : "Šifrēšanas lietotnei nepareiza privātā atslēga. Lūdzu atjaunojiet savu privāto atslēgu personīgo uzstādījumu sadaļā, lai atjaunot pieeju šifrētajiem failiem.",
    "Encryption App is enabled but your keys are not initialized, please log-out and log-in again" : "Šifrēšanas lietotnes ir pieslēgta, bet šifrēšanas atslēgas nav uzstādītas. Lūdzu izejiet no sistēmas un ieejiet sistēmā atpakaļ.",
    "Enabled" : "Pievienots"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");
